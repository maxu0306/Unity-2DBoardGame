using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileGrass : MonoBehaviour
{
    public Vector2Int positionInt;//�^�C���̍��W
    public GameObject grassPrefab;
}
